package PlanetarySystem;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Stack;

/**
 * Manages the planetary system operations including creation, modification,
 * and analysis of celestial bodies.
 */
public class SystemManager {
    /** The planetary system being managed */
    public static PlanetSystem planetSystem = new PlanetSystem();

    /**
     * Creates a new planetary system with a star as the root node.
     * 
     * @param name The name of the star
     * @param temperature The temperature of the star in Kelvin
     * @param pressure The pressure of the star in Pascals
     * @param humidity The humidity percentage of the star (should be 0)
     * @param radiation The radiation level of the star in Sieverts
     */
    private void createPlanetSystem(String name, double temperature, double pressure, double humidity, double radiation){
        planetSystem.createRoot(name, "Star", temperature, pressure, humidity, radiation);
    }

    /**
     * Checks if a planet with the given name exists in the system.
     * 
     * @param node The node to start searching from
     * @param planetName The name of the planet to search for
     * @return true if the planet exists, false otherwise
     */
    private boolean isPlanetExists(PlanetSystemNode node, String planetName){
        if(node.getName().equals(planetName)){
            return true;
        }

        for(PlanetSystemNode child : node.getChilds()){
            if(isPlanetExists(child, planetName)){
                return true;
            }
        }

        return false;
    }

    /**
     * Finds a parent node by name and adds a planet to it if conditions are met.
     * 
     * @param node The current node being examined
     * @param nodeToAdd The planet node to add
     * @param parentName The name of the parent to find
     * @return true if the parent was found, false otherwise
     */
    private boolean findParentAndAddPlanet(PlanetSystemNode node, PlanetSystemNode nodeToAdd, String parentName) {
   
        if (node.getName().equals(parentName)) {
            // parent found
            boolean childHavePlanet = false;

            for(PlanetSystemNode child : node.getChilds()){
                if(child.getType() == "Planet"){
                    childHavePlanet = true;
                }
            }
            if(childHavePlanet){
                System.err.println("A planet can only have one child as a planet. Command failed.");
            }else{
                if(isPlanetExists(node, nodeToAdd.getName())){
                    System.err.println("There is a planet with same name. Command failed.");
                }else{
                    node.addChild(nodeToAdd);
                }
            }
            return true;
        }
        
        // recursive for all childs
        for (PlanetSystemNode child : node.getChilds()) {
            if (findParentAndAddPlanet(child, nodeToAdd, parentName)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Finds a parent node by name and adds a satellite to it if conditions are met.
     * 
     * @param node The current node being examined
     * @param nodeToAdd The satellite node to add
     * @param parentName The name of the parent to find
     * @return true if the parent was found, false otherwise
     */
    private boolean findParentAndAddSatellite(PlanetSystemNode node, PlanetSystemNode nodeToAdd, String parentName) {
   
        if (node.getName().equals(parentName)) {
            // parent found
            if(node.getType() != "Satellite"){
                node.addChild(nodeToAdd);
            }else{
                System.err.println("You cannot add satellite to satellite");
            }
            
            return true;
        }
        
        // recursive for all childs
        for (PlanetSystemNode child : node.getChilds()) {
            if (findParentAndAddSatellite(child, nodeToAdd, parentName)) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * Adds a planet to the system under the specified parent.
     * 
     * @param planetName The name of the planet to add
     * @param parentName The name of the parent celestial body
     * @param temperature The temperature of the planet in Kelvin
     * @param pressure The pressure of the planet in Pascals
     * @param humidity The humidity percentage of the planet
     * @param radiation The radiation level of the planet in Sieverts
     */
    private void addPlanet(String planetName, String parentName, double temperature, double pressure, double humidity, double radiation) {
        if (planetSystem.root == null) {
            return;
        }
        PlanetSystemNode planetToAdd = new PlanetSystemNode(planetName, "Planet", temperature, pressure, humidity, radiation);

        // first planet
        if (parentName.equals(planetSystem.root.getName())) {
            Boolean isStarHavePlanet = false;
            
            for(PlanetSystemNode child : planetSystem.root.getChilds()){
                if(child.getType() == "Planet"){
                    isStarHavePlanet = true;
                }
            }
            if(!isStarHavePlanet){
                planetSystem.root.addChild(planetToAdd);
            }else{
                System.err.println("A Star can only have one planet as a child. Command failed.");
            }
            
            return;
        }
        
        // Preorder traversal for parent
        boolean isPlanetFound = findParentAndAddPlanet(planetSystem.root, planetToAdd, parentName);
        
        if (!isPlanetFound) {
            System.err.println("Planet not found. Command failed");
        }
    }

    /**
     * Adds a satellite to the system under the specified parent.
     * 
     * @param satelliteName The name of the satellite to add
     * @param parentName The name of the parent celestial body
     * @param temperature The temperature of the satellite in Kelvin
     * @param pressure The pressure of the satellite in Pascals
     * @param humidity The humidity percentage of the satellite
     * @param radiation The radiation level of the satellite in Sieverts
     */
    private void addSatellite(String satelliteName, String parentName, double temperature, double pressure, double humidity, double radiation){
        
        if (planetSystem.root == null) {
            return;
        }
        
        PlanetSystemNode satelliteToAdd = new PlanetSystemNode(satelliteName, "Satellite", temperature, pressure, humidity, radiation);

        // first planet
        if (parentName.equals(planetSystem.root.getName())) {
            planetSystem.root.addChild(satelliteToAdd);
            return;
        }
        
        // Preorder traversal for parent
        boolean isPlanetFound = findParentAndAddSatellite(planetSystem.root, satelliteToAdd, parentName);
        
        if (!isPlanetFound) {
            System.err.println("Planet not found. Command failed.");
        }
    }

    /**
     * Finds celestial bodies with radiation levels above a specified threshold.
     * 
     * @param node The node to start searching from
     * @param treshold The radiation threshold in Sieverts
     * @param radiationAnomalies List to store bodies with anomalous radiation
     * @return The updated list of radiation anomalies
     */
    private ArrayList<PlanetSystemNode> findRadiationAnomalies(PlanetSystemNode node, double treshold, ArrayList<PlanetSystemNode> radiationAnomalies){
  
        if(node.getSensorData().getRadiation() > treshold){
            radiationAnomalies.add(node);
        }

        for(PlanetSystemNode child : node.getChilds()){
            findRadiationAnomalies(child, treshold, radiationAnomalies);
        }

        return radiationAnomalies;
    }

    /**
     * Finds the path from the root to a specified planet.
     * Only includes planets and star names in the path.
     * 
     * @param root The root node to start from
     * @param targetPlanet The name of the planet to find
     * @return A stack containing the path to the planet, or null if not found
     */
    private Stack<String> getPathTo(PlanetSystemNode root, String targetPlanet){
        // only planets and star name 
        if(root == null){
            return null;
        }
        Stack<PlanetSystemNode> planetSystemNodes = new Stack<>();
        Stack<String> path = new Stack<>();

        path.push(root.getName());
        planetSystemNodes.push(root);

        while(!planetSystemNodes.isEmpty()){

            PlanetSystemNode current = planetSystemNodes.pop();
            
            if(current.getType() == "Planet"){
                path.push(current.getName());
            }
            
            if(current.getName().equals(targetPlanet)){
                return path;
            }

            for(PlanetSystemNode child : current.getChilds()){
                planetSystemNodes.push(child);
            }
        }
        return null;
    }

    /**
     * Prints a mission report for all celestial bodies in the system.
     * The report includes temperature, pressure, radiation, and humidity readings.
     * 
     * @param node The node to start printing from
     */
    private void printMissionReport(PlanetSystemNode node){
        SensorData sensorData = node.getSensorData();
        double temperature = sensorData.getTemperature();
        double pressure = sensorData.getPressure();
        double radiation = sensorData.getRadiation();
        double humidity = sensorData.getHumidity();
        System.out.printf("Name: %s \nTemperature: %.2f Kelvin \nPressure: %.2f Pascals\nRadiation: %.2f Sieverts\nHumidity: %.2f\n", 
                            node.getName(), temperature, pressure, radiation, humidity);
        System.out.println("--------------------");

        for(PlanetSystemNode child: node.getChilds()){
            printMissionReport(child);
        }
    }

    /**
     * Prints a mission report for a specific celestial body.
     * 
     * @param node The node to start searching from
     * @param nodeName The name of the celestial body to report on
     * @return true if the node was found and report printed, false otherwise
     */
    private boolean printMissionReportNode(PlanetSystemNode node, String nodeName){
        if(node != null){
            if(node.getName().equals(nodeName)){
                SensorData sensorData = node.getSensorData();
                double temperature = sensorData.getTemperature();
                double pressure = sensorData.getPressure();
                double radiation = sensorData.getRadiation();
                double humidity = sensorData.getHumidity();
                System.out.printf("Name: %s \nTemperature: %.2f Kelvin \nPressure: %.2f Pascals\nRadiation: %.2f Sieverts\nHumidity: %.2f\n", 
                                    node.getName(), temperature, pressure, radiation, humidity);
    
                return true;
            }

            for(PlanetSystemNode child: node.getChilds()){
                if (printMissionReportNode(child, nodeName)) {
                    return true;
                }
            }
        }
        
        return false;
    }

    /**
     * Processes a command string and executes the corresponding operation.
     * Supports commands for creating planetary systems, adding planets and satellites,
     * finding radiation anomalies, getting paths to planets, and printing mission reports.
     * 
     * @param command The command string to process
     */
    private void processCommand(String command){
       
        if(command.contains("create planetSystem")){
            ArrayList<String> splitCommand = new ArrayList<>(Arrays.asList(command.split(" ")));
            String starName = splitCommand.get(2);
            String temperature = splitCommand.get(3);
            String pressure = splitCommand.get(4);
            String humidity = splitCommand.get(5);
            String radiation = splitCommand.get(6);

            try{
                double starTemperature = Double.parseDouble(temperature);
                double starPressure = Double.parseDouble(pressure);
                double starHumidity = Double.parseDouble(humidity);
                double starRadiation = Double.parseDouble(radiation);

                if(starHumidity != 0){
                    System.err.println("The humidity of the star must be zero!");
                }else if(starPressure < 0){
                    System.err.println("The pressure of the star cannot be negative. Command failed.");
                }else{
                    createPlanetSystem(starName, starTemperature, starPressure, starHumidity, starRadiation);
                }

            }catch(Exception e){
                System.err.println("SensorData values must be double.\n");
            }
        }else if(command.contains("addPlanet")){
            ArrayList<String> splitCommand = new ArrayList<>(Arrays.asList(command.split(" ")));
            String planetName = splitCommand.get(1);
            String parentName = splitCommand.get(2);
            String temperature = splitCommand.get(3);
            String pressure = splitCommand.get(4);
            String humidity = splitCommand.get(5);
            String radiation = splitCommand.get(6);
            
            try{
                double planetTemperature = Double.parseDouble(temperature);
                double planetPressure = Double.parseDouble(pressure);
                double planetHumidity = Double.parseDouble(humidity);
                double planetRadiation = Double.parseDouble(radiation);
                if(planetPressure < 0){
                    System.err.println("The pressure of the planet cannot be negative. Command failed.");
                }else if(planetHumidity < 0 || planetHumidity > 100){
                    System.err.println("The humidity of the planet should be between 0-100. Command failed.");
                }else{
                    addPlanet(planetName, parentName, planetTemperature, planetPressure, planetHumidity, planetRadiation);
                }

            }catch(Exception e){
                System.err.println("SensorData values must be double.");
            }

        }else if(command.contains("addSatellite")){
            ArrayList<String> splitCommand = new ArrayList<>(Arrays.asList(command.split(" ")));
            String satelliteName = splitCommand.get(1);
            String parentName = splitCommand.get(2);
            String temperature = splitCommand.get(3);
            String pressure = splitCommand.get(4);
            String humidity = splitCommand.get(5);
            String radiation = splitCommand.get(6);

            try{
                double satelliteTemperature = Double.parseDouble(temperature);
                double satellitePressure = Double.parseDouble(pressure);
                double satelliteHumidity = Double.parseDouble(humidity);
                double satelliteRadiation = Double.parseDouble(radiation);
                if(satellitePressure < 0){
                    System.err.println("The pressure of the satellite cannot be negative. Command failed.");
                }else if(satelliteHumidity < 0 || satelliteHumidity > 100){
                    System.err.println("The humidity of the satellite should be between 0-100. Command failed.");
                }else{
                    addSatellite(satelliteName, parentName, satelliteTemperature, satellitePressure, satelliteHumidity, satelliteRadiation);
                }

            }catch(Exception e){
                System.err.println("SensorData values must be double.");
            }

        }else if(command.contains("findRadiationAnomalies")){
            ArrayList<String> splitCommand = new ArrayList<>(Arrays.asList(command.split(" ")));
            String thresholdString = splitCommand.get(1);
            ArrayList<PlanetSystemNode> radiationAnomaliesList = new ArrayList<>();

            try{
                double treshold = Double.parseDouble(thresholdString);
                findRadiationAnomalies(planetSystem.root, treshold, radiationAnomaliesList);

                if(radiationAnomaliesList.size() > 0){
                    System.out.println("Anomalies:");
                    for(PlanetSystemNode anomalie : radiationAnomaliesList){
                        System.out.println(anomalie.getName());
                    }
                }else{
                    System.out.println("No anomalies found.");
                }

            }catch(Exception e){
                System.err.println("Treshold value must be double.");
            }
        }else if(command.contains("getPathTo")){
            ArrayList<String> splitCommand = new ArrayList<>(Arrays.asList(command.split(" ")));
            String targetPlanetName = splitCommand.get(1);
            Stack<String> pathStack = getPathTo(planetSystem.root, targetPlanetName);

            if(pathStack != null){
                System.out.println("Path of target planet:");
                
                for(String name : pathStack){
                    System.out.println(name);
                }

            }else{
                System.err.println("Planet not found. Command Failed.");
            }

        }else if(command.equals("printMissionReport")){
            printMissionReport(planetSystem.root);
        }else if(command.contains("printMissionReport")){
            ArrayList<String> splitCommand = new ArrayList<>(Arrays.asList(command.split(" ")));
            String targetName = splitCommand.get(1);
            boolean isFound = printMissionReportNode(planetSystem.root, targetName);
            
            if(!isFound){
                System.err.println("Target not found!");
            }
        }else{
            if(!command.equals("exit")){
                 System.err.println("Undefined command. Command failed.");

            }   
        }
    }

    /**
     * Runs the planetary system management interface.
     * Reads commands from standard input and processes them until an "exit" command is received.
     * Finally prints the system structure.
     */
    public void runSystem(){
        ArrayList<String> commandList = new ArrayList<>(); 
        
        try (Scanner scanner = new Scanner(System.in)) {
            // Read each line and add it to the ArrayList
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (line.equals("exit")) {
                    commandList.add(line);
                    break; 
                }
                commandList.add(line);
            }
        } catch (Exception e) {
            System.err.println("Error reading from standard input: " + e.getMessage());
            return;
        }

        for (String command : commandList) {
            if (command.equals("exit")) {
                Iterator<String> iterator = commandList.iterator();
                while (iterator.hasNext()) {
                    String commandInList = iterator.next();
                    processCommand(commandInList);
                }
                break; 
            } 
        }
        planetSystem.printSystem();
    }
}
