package PlanetarySystem;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a node in the planetary system hierarchy.
 * Each node corresponds to a celestial body (star, planet, moon, etc.) and can have multiple child nodes.
 */
public class PlanetSystemNode {
    /** The name of the celestial body */
    private String name;
    
    /** The type of the celestial body (e.g., star, planet, moon) */
    private String type;
    
    /** Sensor data containing environmental measurements for this celestial body */
    private SensorData sensorData;
    
    /** List of child nodes (e.g., planets orbiting a star, moons orbiting a planet) */
    private List<PlanetSystemNode> childs;

    /**
     * Constructs a new planetary system node with the specified parameters.
     * 
     * @param name The name of the celestial body
     * @param type The type of the celestial body
     * @param temperature The temperature of the celestial body in Kelvin
     * @param pressure The atmospheric pressure in Pascals
     * @param humidity The humidity percentage
     * @param radiation The radiation level in Sieverts
     */
    public PlanetSystemNode(String name, String type, double temperature, double pressure, double humidity, double radiation){
        this.name = name;
        this.type = type;
        this.childs = new ArrayList<>();
        this.sensorData = new SensorData(temperature, pressure, humidity, radiation);
    }

    /**
     * Adds a child node to this celestial body.
     * For example, adding a planet to a star, or a moon to a planet.
     * 
     * @param child The child node to be added
     */
    public void addChild(PlanetSystemNode child){
        childs.add(child);
    }

    /**
     * Gets the name of this celestial body.
     * 
     * @return The name of the celestial body
     */
    public String getName(){
        return name;
    }

    /**
     * Gets the type of this celestial body.
     * 
     * @return The type of the celestial body (e.g., star, planet, moon)
     */
    public String getType(){
        return type;
    }

    /**
     * Gets the sensor data associated with this celestial body.
     * 
     * @return The SensorData object containing environmental measurements
     */
    public SensorData getSensorData(){
        return sensorData;
    }
    
    /**
     * Gets the list of child nodes of this celestial body.
     * 
     * @return A list of PlanetSystemNode objects representing the children of this node
     */
    public List<PlanetSystemNode> getChilds(){
        return childs;
    }
}
