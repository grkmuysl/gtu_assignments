package PlanetarySystem;

/**
 * Represents environmental sensor data for a celestial body.
 * This class stores various environmental measurements such as temperature,
 * pressure, humidity, and radiation levels.
 */
public class SensorData {
    /** The temperature of the celestial body in Kelvin */
    private double temperature;
    
    /** The atmospheric pressure in Pascals */
    private double pressure;
    
    /** The humidity percentage (0-100) */
    private double humidity;
    
    /** The radiation level in Sieverts */
    private double radiation;

    /**
     * Constructs a new SensorData object with the specified environmental measurements.
     * 
     * @param temperature The temperature in Kelvin
     * @param pressure The atmospheric pressure in Pascals
     * @param humidity The humidity percentage (0-100)
     * @param radiation The radiation level in Sieverts
     */
    public SensorData(double temperature, double pressure, double humidity, double radiation){
        this.temperature = temperature;
        this.pressure = pressure;
        this.humidity = humidity;
        this.radiation = radiation;
    }

    /**
     * Gets the temperature measurement.
     * 
     * @return The temperature in Kelvin
     */
    public double getTemperature(){
        return temperature;
    }

    /**
     * Gets the atmospheric pressure measurement.
     * 
     * @return The pressure in Pascals
     */
    public double getPressure(){
        return pressure;
    }

    /**
     * Gets the humidity measurement.
     * 
     * @return The humidity percentage (0-100)
     */
    public double getHumidity(){
        return humidity;
    }

    /**
     * Gets the radiation level measurement.
     * 
     * @return The radiation level in Sieverts
     */
    public double getRadiation(){
        return radiation;
    }
}
