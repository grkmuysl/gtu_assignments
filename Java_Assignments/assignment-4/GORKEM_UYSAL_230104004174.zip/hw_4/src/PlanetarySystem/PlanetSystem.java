package PlanetarySystem;

/**
 * Represents a hierarchical planetary system with a tree structure.
 * This class manages a system of celestial bodies where each node can have multiple children.
 */
public class PlanetSystem {
    /** The root node of the planetary system tree */
    public PlanetSystemNode root;

    /**
     * Constructs an empty planetary system with no root.
     */
    public PlanetSystem(){
        root = null;
    }

    /**
     * Creates the root node of the planetary system with specified parameters.
     * 
     * @param name The name of the root celestial body
     * @param type The type of the celestial body (e.g., star, planet)
     * @param temperature The temperature of the celestial body in Kelvin
     * @param pressure The atmospheric pressure in Pascals
     * @param humidity The humidity percentage
     * @param radiation The radiation level in Sieverts
     */
    public void createRoot(String name, String type, double temperature, double pressure, double humidity, double radiation){
        root = new PlanetSystemNode(name, type, temperature, pressure, humidity, radiation);
    }

    /**
     * Prints the entire planetary system in a hierarchical tree format.
     * This is a public method that initiates the recursive printing process.
     */
    public void printSystem(){
        System.out.println("Planet system:");
        printSystem(root, 0);
    }

    /**
     * Helper method that recursively prints the planetary system nodes.
     * Each level of the hierarchy is indented to visualize the tree structure.
     * 
     * @param node The current node to print
     * @param level The depth level in the tree, used for indentation
     */
    private void printSystem(PlanetSystemNode node, int level){
        if(node != null){
            // Create indentation based on the level in the hierarchy
            String recess = "";
            for (int i = 0; i < level; i++) {
                recess += "  ";
            }
            // Print the current node with its name and type
            System.out.println(recess + "└─ " + node.getName() + "---" + node.getType());
    
            // Recursively print all children of the current node
            for(PlanetSystemNode child : node.getChilds()){
                printSystem(child, level + 1);
            }
        }
    }
}
