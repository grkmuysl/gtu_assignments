package Main;

import PlanetarySystem.SystemManager;

/**
 * Main class that serves as the entry point for the Planetary System application.
 * This class initializes the system and starts its execution.
 */
public class Main {
   
    /**
     * The main method that starts the application.
     * It creates an instance of SystemManager and calls the runSystem method
     * to begin the operation of the planetary system.
     * 
     * @param args Command line arguments (not used in this application)
     */
    public static void main(String[] args) {
        // Create a new instance of the SystemManager
        SystemManager systemManager = new SystemManager();
        
        // Start the planetary system by calling the runSystem method
        systemManager.runSystem();
    }
}
