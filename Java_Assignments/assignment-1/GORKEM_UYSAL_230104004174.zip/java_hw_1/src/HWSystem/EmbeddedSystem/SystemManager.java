package HWSystem.EmbeddedSystem;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

import HWSystem.Devices.Device;
import HWSystem.Devices.Device.DeviceState;
import HWSystem.Devices.Display.Display;
import HWSystem.Devices.Display.LCD;
import HWSystem.Devices.Display.OLED;
import HWSystem.Devices.MotorDriver.MotorDriver;
import HWSystem.Devices.MotorDriver.PCA9685;
import HWSystem.Devices.MotorDriver.SparkFunMD;
import HWSystem.Devices.Ports.Port;
import HWSystem.Devices.Sensor.Sensor;
import HWSystem.Devices.Sensor.IMUSensor.GY_951;
import HWSystem.Devices.Sensor.IMUSensor.MPU6050;
import HWSystem.Devices.Sensor.TempSensor.BME280;
import HWSystem.Devices.Sensor.TempSensor.DHT11;
import HWSystem.Devices.WirelessIO.Bluetooth;
import HWSystem.Devices.WirelessIO.Wifi;
import HWSystem.Devices.WirelessIO.WirelessIO;
import HWSystem.Protocols.I2C;
import HWSystem.Protocols.OneWire;
import HWSystem.Protocols.Protocol;
import HWSystem.Protocols.SPI;
import HWSystem.Protocols.UART;

public class SystemManager {
    private static ArrayList<Integer> motorDriversIDs = new ArrayList<>();
    private static ArrayList<Integer> DisplaysIDs = new ArrayList<>();
    private static ArrayList<Integer> SensorsIDs = new ArrayList<>();
    private static ArrayList<Integer> WirelessIOIDs = new ArrayList<>();

    private static void processCommand(String command, ArrayList<Protocol> protocolsList, ArrayList<Port> portList, 
    int sensors_count, int displays_count, int wireless_adapters_count, int motor_drivers_count, int ports_count){

        if(command.equals("list ports")){
            System.out.println("list of ports:");
            for(int i = 0; i < ports_count; i++){
                //check is empty or not 
                if(portList.get(i).getEmptyStatus()){ 
                    
                    System.out.printf("%d %s empty\n" , i, portList.get(i).protocol.getProtocolName());
                }else{
                    Device dev = portList.get(i).device;

                    // pattern matching for sensors and others
                    if(dev instanceof Sensor sensor){
                        System.out.printf("%d %s occupied %s %s %s %d %s\n" , i, portList.get(i).protocol.getProtocolName(), 
                        dev.getName(), sensor.getSensType() ,dev.getDevType() , dev.getDevID() ,dev.getState());
                    }else{
                        System.out.printf("%d %s occupied %s %s %d %s\n" , i, portList.get(i).protocol.getProtocolName(), 
                        dev.getName() ,dev.getDevType() , dev.getDevID() ,dev.getState());
                    }
                }
             
            }
        }else if(command.contains("addDev")){ 
            
            String[] splitCommand = command.split(" ");

            // check first word is equal addDev command if it is then add new device
            // if I don't add this condition for example addDevvv is acceptable

            if(splitCommand[0].equals("addDev")){
                if(splitCommand.length == 4){
                    String devType = splitCommand[1];
                   
                    // try catch for parseInt
                    try{
                        int portId = Integer.parseInt(splitCommand[2]);
                        int devId = Integer.parseInt(splitCommand[3]);
                        
                        if(portId < 0 || portId >= ports_count){
                            System.out.printf("Invalid port ID.\nCommand failed.\n");
                        }else{
                            if(devType.equals("DHT11")){
                                if(portId == 2){
                                    // check if is empty
                                    if(portList.get(portId).getEmptyStatus()){
                                        if(devId >= 0 && devId < sensors_count){
                                            // check if there is a device with same ids
                                            if(!SensorsIDs.contains(devId)){
                                                Device newDevice = new DHT11(protocolsList.get(portId) , devId);
                                                portList.get(portId).setDevice(newDevice);
                                                portList.get(portId).setEmptyStatus(false);
                                                SensorsIDs.add(devId);
                                            }else{
                                                System.out.printf("There is a device with the same ID.\nCommand failed.\n");
                                            }
                                        }else{
                                            System.out.printf("Invalid device ID.\nCommand failed.\n");
                                        }
                                    }else{
                                        System.out.printf("The port is full.\nCommand failed.\n");
                                    }
                                    
                                }else{
                                    System.out.printf("The device's protocol is not compatible with this port.\nCommand failed.\n");
                                }
                            }else if(devType.equals("MPU6050")){
                                if(portId == 0){
                                    // check if is empty
                                    if(portList.get(portId).getEmptyStatus()){
                                        if(devId >= 0 && devId < sensors_count){
                                            if(!SensorsIDs.contains(devId)){
                                                Device newDevice = new MPU6050(protocolsList.get(portId) , devId);
                                                portList.get(portId).setDevice(newDevice);
                                                portList.get(portId).setEmptyStatus(false);
                                                SensorsIDs.add(devId);
                                            }else{
                                                System.out.printf("There is a device with the same ID.\nCommand failed.\n");
                                            }
                                        }else{
                                            System.out.printf("Invalid device ID.\nCommand failed.\n");
                                        }
                                    }else{
                                        System.out.printf("The port is full.\nCommand failed.\n");
                                    }
                                    
                                }else{
                                    System.out.printf("The device's protocol is not compatible with this port.\nCommand failed.\n");
                                }
                            }else if(devType.equals("LCD")){
                                if(portId == 0){
                                    // check if is empty
                                    if(portList.get(portId).getEmptyStatus()){
                                        if(devId >= 0 && devId < displays_count){
                                            if(!DisplaysIDs.contains(devId)){
                                                Device newDevice = new LCD(protocolsList.get(portId) , devId);
                                                portList.get(portId).setDevice(newDevice);
                                                portList.get(portId).setEmptyStatus(false);
                                                DisplaysIDs.add(devId);
                                            }else{
                                                System.out.printf("There is a device with the same ID.\nCommand failed.\n");
                                            }
                                        }else{
                                            System.out.printf("Invalid device ID.\nCommand failed.\n");
                                        }
                                    }else{
                                        System.out.printf("The port is full.\nCommand failed.\n");
                                    }
                                    
                                }else{
                                    System.out.printf("The device's protocol is not compatible with this port.\nCommand failed.\n");
                                }
                            }else if(devType.equals("OLED")){
                                if(portId == 1){
                                    // check if is empty
                                    if(portList.get(portId).getEmptyStatus()){
                                        if(devId >= 0 && devId < displays_count){
                                            if(!DisplaysIDs.contains(devId)){
                                                Device newDevice = new OLED(protocolsList.get(portId) , devId);
                                                portList.get(portId).setDevice(newDevice);
                                                portList.get(portId).setEmptyStatus(false);
                                                DisplaysIDs.add(devId);
                                            }else{
                                                System.out.printf("There is a device with the same ID.\nCommand failed.\n");
                                            }
                                        }else{
                                            System.out.printf("Invalid device ID.\nCommand failed.\n");
                                        }
                                    }else{
                                        System.out.printf("The port is full.\nCommand failed.\n");
                                    }
                                    
                                }else{
                                    System.out.printf("The device's protocol is not compatible with this port.\nCommand failed.\n");
                                }
                            }else if(devType.equals("Bluetooth")){
                                if(portId == 3){
                                    // check if is empty
                                    if(portList.get(portId).getEmptyStatus()){
                                        if(devId >= 0 && devId < wireless_adapters_count){
                                            if(!WirelessIOIDs.contains(devId)){
                                                Device newDevice = new Bluetooth(protocolsList.get(portId) , devId);
                                                portList.get(portId).setDevice(newDevice);
                                                portList.get(portId).setEmptyStatus(false);
                                                WirelessIOIDs.add(devId);
                                            }else{
                                                System.out.printf("There is a device with the same ID.\nCommand failed.\n");
                                            }
                                        }else{
                                            System.out.printf("Invalid device ID.\nCommand failed.\n");
                                        }
                                    
                                    }else{
                                        System.out.printf("The port is full.\nCommand failed.\n");
                                    }
                                    
                                }else{
                                    System.out.printf("The device's protocol is not compatible with this port.\nCommand failed.\n");
                                }
                            }else if(devType.equals("PCA9685")){
                                if(portId == 0){
                                    // check if is empty
                                    if(portList.get(portId).getEmptyStatus()){
                                        if(devId >= 0 && devId < motor_drivers_count){
                                            if(!motorDriversIDs.contains(devId)){
                                                Device newDevice = new PCA9685(protocolsList.get(portId) , devId);
                                                portList.get(portId).setDevice(newDevice);
                                                portList.get(portId).setEmptyStatus(false);
                                                motorDriversIDs.add(devId);
                                            }else{
                                                System.out.printf("There is a device with the same ID.\nCommand failed.\n");
                                            }
                                        }else{
                                            System.out.printf("Invalid device ID.\nCommand failed.\n");
                                        }
                                        
                                    }else{
                                        System.out.printf("The port is full.\nCommand failed.\n");
                                    }
                                    
                                }else{
                                    System.out.printf("The device's protocol is not compatible with this port.\nCommand failed.\n");
                                }
                            }else if(devType.equals("SparkFunMD")){
                                if(portId == 1){
                                    // check if is empty
                                    if(portList.get(portId).getEmptyStatus()){
                                        if(devId >= 0 && devId < motor_drivers_count){
                                            if(!motorDriversIDs.contains(devId)){
                                                Device newDevice = new SparkFunMD(protocolsList.get(portId) , devId);
                                                portList.get(portId).setDevice(newDevice);
                                                portList.get(portId).setEmptyStatus(false);
                                                motorDriversIDs.add(devId);
                                            }else{
                                                System.out.printf("There is a device with the same ID.\nCommand failed.\n");
                                            }
                                        }else{
                                            System.out.printf("Invalid device ID.\nCommand failed.\n");
                                        }
                                        
                                    }else{
                                        System.out.printf("The port is full.\nCommand failed.\n");
                                    }
                                    
                                }else{
                                    System.out.printf("The device's protocol is not compatible with this port.\nCommand failed.\n");
                                }
                            }else if(devType.equals("BME280")){
                                if(portId == 0 || portId == 1 ){
                                    // check if is empty
                                    if(portList.get(portId).getEmptyStatus()){
                                        if(devId >= 0 && devId < sensors_count){
                                            if(!SensorsIDs.contains(devId)){
                                                Device newDevice = new BME280(protocolsList.get(portId) , devId);
                                                portList.get(portId).setDevice(newDevice);
                                                portList.get(portId).setEmptyStatus(false);
                                                SensorsIDs.add(devId);
                                            }else{
                                                System.out.printf("There is a device with the same ID.\nCommand failed.\n");
                                            }
                                        }else{
                                            System.out.printf("Invalid device ID.\nCommand failed.\n");
                                        }
                                        
                                    }else{
                                        System.out.printf("The port is full.\nCommand failed.\n");
                                    }
                                    
                                }else{
                                    System.out.printf("The device's protocol is not compatible with this port.\nCommand failed.\n");
                                }
                            }else if(devType.equals("GY951")){
                                if(portId == 1 || portId == 3 ){
                                    // check if is empty
                                    if(portList.get(portId).getEmptyStatus()){
                                        if(devId >= 0 && devId < sensors_count){
                                            if(!SensorsIDs.contains(devId)){
                                                Device newDevice = new GY_951(protocolsList.get(portId) , devId);
                                                portList.get(portId).setDevice(newDevice);
                                                portList.get(portId).setEmptyStatus(false);
                                                SensorsIDs.add(devId);
                                            }else{
                                                System.out.printf("There is a device with the same ID.\nCommand failed.\n");
                                            }
                                        }else{
                                            System.out.printf("Invalid device ID.\nCommand failed.\n");
                                        }
                                        
                                    }else{
                                        System.out.printf("The port is full.\nCommand failed.\n");
                                    }
                                    
                                }else{
                                    System.out.printf("The device's protocol is not compatible with this port.\nCommand failed.\n");
                                }
                            }else if(devType.equals("Wifi")){
                                if(portId == 1 || portId == 3 ){
                                    // check if is empty
                                    if(portList.get(portId).getEmptyStatus()){
                                        if(devId >= 0 && devId < wireless_adapters_count){
                                            if(!WirelessIOIDs.contains(devId)){
                                                Device newDevice = new Wifi(protocolsList.get(portId) , devId);
                                                portList.get(portId).setDevice(newDevice);
                                                portList.get(portId).setEmptyStatus(false);
                                                WirelessIOIDs.add(devId);
                                            }else{
                                                System.out.printf("There is a device with the same ID.\nCommand failed.\n");
                                            }
                                        }else{
                                            System.out.printf("Invalid device ID.\nCommand failed.\n");
                                        }
                                        
                                    }else{
                                        System.out.printf("The port is full.\nCommand failed.\n");
                                    }
                                    
                                }else{
                                    System.out.printf("The device's protocol is not compatible with this port.\nCommand failed.\n");
                                }
                            }else{
                                System.out.printf("Invalid device name.\nCommand failed.\n");
                            }
                        }
                    }catch(Exception e){
                        System.out.println("Ids must be integers.\nCommand failed.");
                    }
                    
                }else{
                    System.out.printf("Undefined command.\nCommand failed.\n");
                }
            }else{
                System.out.printf("Undefined command.\nCommand failed.\n");
            }
            
        }else if(command.contains("turnON")){
            // check is contains turnON command if it is then turn on the device
            String[] splitCommand = command.split(" ");
            
            if(splitCommand[0].equals("turnON")){
                if(splitCommand.length == 2){
                    try{
                        int portID = Integer.parseInt(splitCommand[1]);
                        if(portID < portList.size() && portID >= 0){
                            if(!portList.get(portID).getEmptyStatus()){
                                if(portList.get(portID).device.getState() == DeviceState.OFF){
                                    
                                    portList.get(portID).device.turnOn();
                                    portList.get(portID).protocol.write("turnON");
                                }else{
                                    System.out.printf("The device is already turned on!\nCommand failed.\n");
                                }
                                
                            }else{
                                System.out.printf("The port is empty!\nCommand failed.\n");
                            }
                        }else{
                            System.out.printf("The port not found!\nCommand failed.\n");
                        }
                    }catch(Exception e){
                        System.out.println("Port ID must be integers.\nCommand failed.");
                    }
                    
                }else{
                    System.out.printf("Undefined command.\nCommand failed.\n");
                }
            }else{
                System.out.printf("Undefined command.\nCommand failed.\n");
            }
            
            
            
        }else if(command.contains("turnOFF")){
            // check is contains turnOFF command if it is then turn on the device
            String[] splitCommand = command.split(" ");
            
            if(splitCommand[0].equals("turnOFF")){
                if(splitCommand.length == 2){
                    try{
                        int portID = Integer.parseInt(splitCommand[1]);
    
                        if(portID < portList.size() && portID >= 0){
                            if(!portList.get(portID).getEmptyStatus()){
                                if(portList.get(portID).device.getState() == DeviceState.ON){
                                    portList.get(portID).device.turnOff();
                                    portList.get(portID).protocol.write("'turnOFF'");
                                }else{
                                    System.out.printf("The device is already turned off!\nCommand failed.\n");
                                }
                                
                            }else{
                                System.out.printf("The port is empty!\nCommand failed.\n");
                            }
                        }else{
                            System.out.printf("The port not found!\nCommand failed.\n");
                        }
                    }catch(Exception e){
                        System.out.println("Port ID must be integers.\nCommand failed.");
                    }
                    
                }else{
                    System.out.printf("Undefined command.\nCommand failed.\n");
                }
            }else{
                System.out.printf("Undefined command.\nCommand failed.\n");
            }
           
            
            
            
        }else if(command.contains("rmDev")){
            String[] splitCommand = command.split(" ");
            if(splitCommand[0].equals("rmDev")){
                if(splitCommand.length == 2){
                    int portID = Integer.parseInt(splitCommand[1]);
                    try{
                        if(portID < portList.size() && portID >= 0){
                            // if port is not empty
                            if(!portList.get(portID).getEmptyStatus()){
                                if(portList.get(portID).device.getState() == DeviceState.OFF){
                                    portList.get(portID).deleteDevice();
                                }else{
                                    System.out.printf("Device is active.\nCommand failed.\n");
                                }
                                
                            }else{
                                System.out.printf("The port is empty!\nCommand failed.\n");
                            }
                        }else{
                            System.out.printf("The port not found!\nCommand failed.\n");
                        }
                    }catch(Exception e){
                        System.out.println("Port ID must be integers.\nCommand failed.");
                    }
                    
                }else{
                    System.out.printf("Undefined command.\nCommand failed.\n");
                }
            }else{
                System.out.printf("Undefined command.\nCommand failed.\n");
            }
                
            
        }else if(command.equals("list Sensor")){
            
            // flag for empty states
            boolean isEmpty = true; 
            for(int portId = 0; portId < portList.size(); portId++){
                    Device dev = portList.get(portId).device;
                    // pattern matching for find sensors
                    if(dev instanceof Sensor sensor){
                        isEmpty = false;
                        System.out.println("list of Sensor");
                        System.out.printf("%s %d %d %s\n" , sensor.getName(), dev.getDevID(), portId, portList.get(portId).protocol.getProtocolName());
                    }
            }
            if(isEmpty){
                System.out.println("Sensor list is empty.");
            }

        }else if(command.equals("list Display")){
            // flag for empty states
            boolean isEmpty = true; 

            for(int portId = 0; portId < portList.size(); portId++){
                    Device dev = portList.get(portId).device;
                    // pattern matching for find display
                    if(dev instanceof Display display){
                        isEmpty = false;
                        System.out.println("list of Display");
                        System.out.printf("%s %d %d %s\n" , display.getName(), dev.getDevID(), portId, portList.get(portId).protocol.getProtocolName());
                    }
            }
            if(isEmpty){
                System.out.println("Display list is empty.");
            }

        }else if(command.equals("list WirelessIO")){
            boolean isEmpty = true; 
            for(int portId = 0; portId < portList.size(); portId++){
                    Device dev = portList.get(portId).device;
                    // pattern matching for find WirelessIO
                    if(dev instanceof WirelessIO wirelessIO){
                        isEmpty = false;
                        System.out.println("list of WirelessIO");
                        System.out.printf("%s %d %d %s\n" , wirelessIO.getName(), dev.getDevID(), portId, portList.get(portId).protocol.getProtocolName());
                    }
            }
            if(isEmpty){
                System.out.println("WirelessIO list is empty.");
            }

        }else if(command.equals("list MotorDriver")){
            boolean isEmpty = true; 
            for(int portId = 0; portId < portList.size(); portId++){
                    Device dev = portList.get(portId).device;
                    // pattern matching for find MotorDriver
                    if(dev instanceof MotorDriver motorDriver){
                        isEmpty = false;
                        System.out.println("list of MotorDriver");
                        System.out.printf("%s %d %d %s\n" , motorDriver.getName(), dev.getDevID(), portId, portList.get(portId).protocol.getProtocolName());
                    }
            }
            if(isEmpty){
                System.out.println("MotorDriver list is empty.");
            }

        }else if(command.contains("readSensor")){
            String[] splitCommand = command.split(" ");
            if(splitCommand[0].equals("readSensor")){
                if(splitCommand.length == 2){
                    int devID = Integer.parseInt(splitCommand[1]);
                    boolean isFound = false;
                    try{
                        // find device with devID
                        for(int i = 0; i < portList.size(); i++){
                            if(portList.get(i).device != null){
                                Device dev = portList.get(i).device;
                                // if they are equal then device  found
                                if(dev.getDevID() == devID){
                                    isFound = true;
                                    // check device state ON/OFF
                                    if(dev instanceof Sensor sensor){
                                        if(dev.getState() == DeviceState.ON){
                                            String data = sensor.data2String();
                                            System.out.printf("%s %s %s: %s \n" , sensor.getName() ,sensor.getSensType() ,sensor.getDevType(), data);
                                        }else{
                                            System.out.printf("Device is not active.\nCommand failed.\n");
                                        }
                                    }
                                }
                            }
                        }
                        // if device not found
                        if(!isFound){
                            System.out.printf("Device not found.\nCommand failed.\n");
                        }
                    }catch(Exception e){
                        System.out.println("Device ID must be integers.\nCommand failed.");
                    }
                    
                }else{
                    System.out.printf("Undefined command.\nCommand failed.\n");
                }
            }else{
                System.out.printf("Undefined command.\nCommand failed.\n");
            }
            
           
        }else if(command.contains("printDisplay")){
            String[] splitCommand = command.split(" ");
            if(splitCommand[0].equals("printDisplay")){
                if(splitCommand.length == 3){
                    String inputData = splitCommand[2];
                    int devID = Integer.parseInt(splitCommand[1]);
                    boolean isFound = false;
                    
                    try{
                        // find device with devID
                        for(int i = 0; i < portList.size(); i++){
                            if(portList.get(i).device != null){
                                Device dev = portList.get(i).device;
                                // if they are equal then device  found
                                if(dev.getDevID() == devID){
                                    isFound = true;
                                    // check device state ON/OFF
                                    if(dev instanceof Display display){
                                        if(dev.getState() == DeviceState.ON){
                                            display.printData(inputData);
                                        }else{
                                            System.out.printf("Device is not active.\nCommand failed.\n");
                                        }
                                    }
                                }
                            }
                        }
                        // if device not found
                        if(!isFound){
                            System.out.printf("Device not found.\nCommand failed.\n");
                        }
                    }catch(Exception e){
                        System.out.println("Device ID must be integers.\nCommand failed.");
                    }
                    
                }else{
                    System.out.printf("Undefined command.\nCommand failed.\n");
                }
            }else{
                System.out.printf("Undefined command.\nCommand failed.\n");
            }
            
            
        }else if(command.contains("readWireless")){
            String[] splitCommand = command.split(" ");
            if(splitCommand[0].equals("readWireless")){
                if(splitCommand.length == 2){
                    try{
                        int devID = Integer.parseInt(splitCommand[1]);
                        boolean isFound = false;
                        // find device with devID
                        for(int i = 0; i < portList.size(); i++){
                            if(portList.get(i).device != null){
                                Device dev = portList.get(i).device;
                                // if they are equal then device  found
                                if(dev.getDevID() == devID){
                                    isFound = true;
                                    // check device state ON/OFF
                                    if(dev instanceof WirelessIO wirelessIO){
                                        if(dev.getState() == DeviceState.ON){
                                            System.out.printf("%s \n" , wirelessIO.recvData());
                                        }else{
                                            System.out.printf("Device is not active.\nCommand failed.\n");
                                            break;
                                        }
                                    }
                                }
                            }
                        }
        
                        // if device not found
                        if(!isFound){
                            System.out.printf("Device not found.\nCommand failed.\n");
                        }
                    }catch(Exception e){
                        System.out.println("Device ID must be integers.\nCommand failed.");
                    }
                    
                }else{
                    System.out.printf("Undefined command.\nCommand failed.\n");
                }
            }else{
                System.out.printf("Undefined command.\nCommand failed.\n");
            }
            
            
        }else if(command.contains("writeWireless")){
            String[] splitCommand = command.split(" ");
            if(splitCommand[0].equals("writeWireless")){
                if(splitCommand.length == 3){
                    try{
                        int devID = Integer.parseInt(splitCommand[1]);
                        String inputData = splitCommand[2];
                        boolean isFound = false;
        
                        // find device with devID
                        for(int i = 0; i < portList.size(); i++){
                            if(portList.get(i).device != null){
                                Device dev = portList.get(i).device;
                                // if they are equal then device  found
                                if(dev.getDevID() == devID){
                                    isFound = true;
                                    // check device state ON/OFF
                                    if(dev instanceof WirelessIO wirelessIO){
                                        if(dev.getState() == DeviceState.ON){
                                            wirelessIO.sendData(inputData);
                                        }else{
                                            System.out.printf("Device is not active.\nCommand failed.\n");
                                            break;
                                        }
                                    }
                                }
                            }
                        }
        
                        // if device not found
                        if(!isFound){
                            System.out.printf("Device not found.\nCommand failed.\n");
                        }
                    }catch(Exception e){
                        System.out.println("Device ID must be integers.\nCommand failed.");
                    }
                    
                }else{
                    System.out.printf("Undefined command.\nCommand failed.\n");
                }
            }else{
                System.out.printf("Undefined command.\nCommand failed.\n");
            }
            
            
        }else if(command.contains("setMotorSpeed")){
            String[] splitCommand = command.split(" ");
            if(splitCommand[0].equals("setMotorSpeed")){
                if(splitCommand.length == 3){
                    try{
                        int devID = Integer.parseInt(splitCommand[1]);
                        int motorSpeed = Integer.parseInt(splitCommand[2]);
                        boolean isFound = false;
        
                        // find device with devID
                        for(int i = 0; i < portList.size(); i++){
                            if(portList.get(i).device != null){
                                Device dev = portList.get(i).device;
                                // if they are equal then device  found
                                if(dev.getDevID() == devID){
                                    isFound = true;
                                    // check device state ON/OFF
                                    if(dev instanceof MotorDriver motorDriver){
                                        if(dev.getState() == DeviceState.ON){
                                            motorDriver.setMotorSpeed(motorSpeed);
                                        }
                                        else{
                                            System.out.printf("Device is not active.\nCommand failed.\n");
                                            break;
                                        }
                                    }
                                }
                            }
                        }
        
                        // if device not found
                        if(!isFound){
                            System.out.printf("Device not found.\nCommand failed.\n");
                        }
                    }catch(Exception e){
                        System.out.println("Device ID and motor speed value must be integers.\nCommand failed.");
                    }
                    
                }else{
                    System.out.printf("Undefined command.\nCommand failed.\n");
                }
            }else{
                System.out.printf("Undefined command.\nCommand failed.\n");
            }
            
        }else{
            System.out.printf("Undefined command.\nCommand failed.\n");
        }
    }
    
    public void RunSystem(String filePath){
        int[] ports_initial_values = {0,0,0,0};
        int ind_for_initial_values = 0;

        int ports_count = 0;
        int sensors_count = 0;
        int displays_count = 0;
        int wireless_adapters_count = 0;
        int motor_drivers_count = 0;
        boolean isCont = true;

        ArrayList<Protocol> protocolsList = new ArrayList<>();
        ArrayList<Port> portsList = new ArrayList<>();

        // file reading
        try (Scanner scanner = new Scanner(new File(filePath))) {
            
            //first line
            String line = scanner.nextLine();
            String[] first_line = line.split(":");
            String[] protocols = first_line[1].split(",");
            ports_count = protocols.length;
           
            for(int i = 0; i < ports_count ; i++){
                // trim for whitespaces
                // add to protocolsList arrayList
                
                if(protocols[i].trim().equals("I2C")){
                    protocolsList.add(new I2C());

                }else if(protocols[i].trim().equals("SPI")){
                    protocolsList.add(new SPI());

                }else if(protocols[i].trim().equals("OneWire")){
                    protocolsList.add(new OneWire());

                }else if(protocols[i].trim().equals("UART")){
                    protocolsList.add(new UART());
                }
                
            }

            for(int port_ind = 0; port_ind < ports_count; port_ind++){
                portsList.add(new Port(protocolsList.get(port_ind), null, true,port_ind));
            }


            while (scanner.hasNextLine()) {
                line = scanner.nextLine();
                String[] values = line.split(":");
                ports_initial_values[ind_for_initial_values] = Integer.parseInt(values[1]);
                ind_for_initial_values+=1;
            }
            
        } catch (Exception e) {
            System.err.println("Couldn't find file: " + e.getMessage());
        }

        for(int i = 0; i < 4; i++){
            switch(i){
                case 0:
                sensors_count = ports_initial_values[i];
                break;

                case 1:
                displays_count = ports_initial_values[i];
                break;

                case 2:
                wireless_adapters_count = ports_initial_values[i];
                break;

                case 3:
                motor_drivers_count = ports_initial_values[i];
                break;
            }
        }
        
        Scanner scanner = new Scanner(System.in);
        String command;
       
        while(isCont){
            System.out.printf("Command: ");
            command = scanner.nextLine();
            if(command.equals("exit")){
                scanner.close();
                isCont = false;
                break;
            }else{
                processCommand(command, protocolsList, portsList ,sensors_count,displays_count,wireless_adapters_count,motor_drivers_count,ports_count);
            }
       }
    }
  
}
