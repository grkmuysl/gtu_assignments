package HWSystem.Devices;

import HWSystem.Protocols.Protocol;

// enum structure for ON/OFF states


public abstract class Device {
    public enum DeviceState {
        ON, OFF
    }
    protected Protocol protocol;
    private int deviceId;
    
    // constructor
    public Device(Protocol protocol, int DevID) {
        this.protocol = protocol;
        this.deviceId = DevID;
    }

    public int getDevID(){
        return deviceId;
    }
    
    public abstract void turnOn();
    public abstract void turnOff();
    public abstract String getName();
    public abstract String getDevType();
    public abstract DeviceState getState();
}
