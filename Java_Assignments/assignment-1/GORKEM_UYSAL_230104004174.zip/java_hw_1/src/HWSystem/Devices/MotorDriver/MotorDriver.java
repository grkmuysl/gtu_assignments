package HWSystem.Devices.MotorDriver;

import HWSystem.Devices.Device;
import HWSystem.Protocols.Protocol;

public abstract class MotorDriver extends Device{
    // constructor
    public MotorDriver(Protocol protocol, int DevID){
        super(protocol, DevID);
    }

    public abstract void setMotorSpeed(int speed);
    @Override
    public String getDevType(){
        return "MotorDriver";
    }
    
}