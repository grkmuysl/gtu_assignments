package HWSystem.Devices.MotorDriver;

import HWSystem.Protocols.Protocol;

public class PCA9685 extends MotorDriver{

    // constructor
    public PCA9685(Protocol protocol, int DevID){
        super(protocol, DevID);
    }

    // initial values
    private int motorSpeed = 0;
    protected DeviceState state = DeviceState.OFF;


    @Override
    public void setMotorSpeed(int speed){
         // turn int speed value to string
         String speed_str = String.valueOf(speed);
        
         // protocol write method
         super.protocol.write(speed_str);

        System.out.printf("Setting %s's motor speed to %d\n" , getName() , speed);
        motorSpeed = speed;
    }

    @Override
    public void turnOn(){
        System.out.printf("%s: Turning ON. \n" ,getName() );
        state = DeviceState.ON;
    }
    @Override
    public void turnOff(){
        System.out.printf("%s: Turning OFF. \n" ,getName() );
        state = DeviceState.OFF;
    }
    @Override
    public String getName(){
        return "PCA9685";
    }
   
    @Override
    public DeviceState getState(){
        return state;
    }

}
