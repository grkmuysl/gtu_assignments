package HWSystem.Devices.Sensor.TempSensor;

import HWSystem.Protocols.Protocol;

public class DHT11 extends TempSensor{
    // constructor
    public DHT11(Protocol protocol, int DevID){
        super(protocol, DevID);
    }

    protected DeviceState state = DeviceState.OFF;
    private float temp = 30.5f;

    @Override
    float getTemp(){
        super.protocol.read();
        return temp;
    }

    @Override
    public String getSensType(){
        return "TempSensor";
    }

    @Override
    public String data2String() {
        String data = String.format("Temperature: %.2fC", temp);
        return data;
    }


    @Override
    public void turnOn(){
        System.out.printf("%s: Turning ON. \n" ,getName() );
        state = DeviceState.ON;
    }
    @Override
    public void turnOff(){
        System.out.printf("%s: Turning OFF. \n" ,getName() );
        state = DeviceState.OFF;
    }
    @Override
    public String getName(){
        return "DHT11";
    }
 
    @Override
    public DeviceState getState(){
        return state;
    }
}
