package HWSystem.Devices.Sensor.IMUSensor;

import HWSystem.Devices.Sensor.Sensor;
import HWSystem.Protocols.Protocol;

public abstract class IMUSensor extends Sensor {
    // constructor
    public IMUSensor(Protocol protocol, int DevID){
        super(protocol, DevID);
    }
    
    abstract float getAccel();
    abstract float getRot();
}