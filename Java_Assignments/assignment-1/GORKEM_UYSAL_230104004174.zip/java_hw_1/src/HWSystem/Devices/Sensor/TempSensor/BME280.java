package HWSystem.Devices.Sensor.TempSensor;

import HWSystem.Protocols.Protocol;

public class BME280 extends TempSensor{

    // constructor
    public BME280(Protocol protocol, int DevID){
        super(protocol, DevID);
    }

    protected DeviceState state = DeviceState.OFF;
    private float temp = 35.5f;

    @Override
    float getTemp(){
        super.protocol.read();
        return 0.0f;
    }

    @Override
    public String getSensType(){
        return "TempSensor";
    }

    @Override
    public String data2String() {
        String data = String.format("Temperature: %.2fC", temp);
        return data;
    }


    @Override
    public void turnOn(){
        System.out.printf("%s: Turning ON. \n" ,getName() );
        state = DeviceState.ON;
    }
    @Override
    public void turnOff(){
        System.out.printf("%s: Turning OFF. \n" ,getName() );
        state = DeviceState.OFF;
    }
    @Override
    public String getName(){
        return "BME280";
    }
   
    @Override
    public DeviceState getState(){
        return state;
    }
}
