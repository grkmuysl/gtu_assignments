package HWSystem.Devices.Sensor.IMUSensor;

import HWSystem.Protocols.Protocol;

public class MPU6050 extends IMUSensor{

    // constructor
    public MPU6050(Protocol protocol, int DevID){
        super(protocol, DevID);
    }

    protected DeviceState state = DeviceState.OFF;
    
    private float acceleration = 1.5f;
    private float rotation = 2.5f;

    @Override
    public String getSensType(){
        return "IMUSensor";
    }

    @Override
    public String data2String() {
        String data = String.format("Accel: %.2f, Rot: %.2f", getAccel(), getRot());
        return data;
    }

    @Override
    float getAccel(){
        super.protocol.read();
        return acceleration;
    }
    @Override
    float getRot(){
        super.protocol.read();
        return rotation;
    }

    @Override
    public void turnOn(){
        System.out.printf("%s: Turning ON. \n" ,getName() );
        state = DeviceState.ON;
    }
    @Override
    public void turnOff(){
        System.out.printf("%s: Turning OFF. \n" ,getName() );
        state = DeviceState.OFF;
    }
    @Override
    public String getName(){
        return "MPU6050";
    }
 
    @Override
    public DeviceState getState(){
        return state;
    }

}