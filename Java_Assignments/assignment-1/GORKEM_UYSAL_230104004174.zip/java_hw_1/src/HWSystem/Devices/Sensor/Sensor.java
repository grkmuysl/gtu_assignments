package HWSystem.Devices.Sensor;

import HWSystem.Devices.Device;
import HWSystem.Protocols.Protocol;

public abstract class Sensor extends Device{
    // constructor 
    public Sensor(Protocol protocol, int DevID){
        super(protocol, DevID);
    }
    public abstract String getSensType();
    public abstract String data2String();
    
    @Override
    public String getDevType(){
        return "Sensor";
    }
}
