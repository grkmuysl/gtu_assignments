package HWSystem.Devices.Sensor.TempSensor;

import HWSystem.Devices.Sensor.Sensor;
import HWSystem.Protocols.Protocol;

public abstract class TempSensor extends Sensor{
    // constructor
    public TempSensor(Protocol protocol, int DevID){
        super(protocol, DevID);
    }
    abstract float getTemp();
}
