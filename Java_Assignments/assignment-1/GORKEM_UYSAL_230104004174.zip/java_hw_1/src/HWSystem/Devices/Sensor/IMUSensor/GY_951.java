package HWSystem.Devices.Sensor.IMUSensor;

import HWSystem.Protocols.Protocol;

public class GY_951 extends IMUSensor{
    // constructor
    public GY_951(Protocol protocol, int DevID){
        super(protocol, DevID);
    }

    protected DeviceState state = DeviceState.OFF;
    
    private float acceleration = 7.2f;
    private float rotation = 4.2f;
    

    @Override
    public String getSensType(){
        return "IMUSensor";
    }

    @Override
    public String data2String() {
        String data = String.format("Accel: %.2f, Rot: %.2f", acceleration, rotation);
        return data;
    }

    @Override
    float getAccel(){
        super.protocol.read();
        return acceleration;
    }
    @Override
    float getRot(){
        return rotation;
    }

    @Override
    public void turnOn(){
        System.out.printf("%s: Turning ON. \n" ,getName() );
        state = DeviceState.ON;
    }
    @Override
    public void turnOff(){
        System.out.printf("%s: Turning OFF. \n" ,getName() );
        state = DeviceState.OFF;
    }
    @Override
    public String getName(){
        return "GY_951";
    }
    @Override
    public DeviceState getState(){
        return state;
    }

}