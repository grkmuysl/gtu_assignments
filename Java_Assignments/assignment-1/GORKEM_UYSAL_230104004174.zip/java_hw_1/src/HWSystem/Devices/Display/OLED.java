package HWSystem.Devices.Display;

import HWSystem.Protocols.Protocol;

public class OLED extends Display{

    // constructor
    public OLED(Protocol protocol, int DevID){
        super(protocol, DevID);
    }

    protected DeviceState state = DeviceState.OFF;

    @Override
    public void printData(String data){
        super.protocol.write(data);
    }
    @Override
    public void turnOn(){
        System.out.printf("%s: Turning ON. \n" ,getName() );
        state = DeviceState.ON;
    }
    @Override
    public void turnOff(){
        System.out.printf("%s: Turning OFF. \n" ,getName() );
        state = DeviceState.OFF;
    }
    @Override
    public String getName(){
        return "OLED";
    }
    
    @Override
    public DeviceState getState(){
        return state;
    }
}
