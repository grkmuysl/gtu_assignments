package HWSystem.Devices.Display;

import HWSystem.Devices.Device;
import HWSystem.Protocols.Protocol;

public abstract class Display extends Device {
    public Display(Protocol protocol, int DevID){
        super(protocol, DevID);
    }

    public abstract void printData(String data);
    
    @Override
    public String getDevType(){
        return "Display";
    }
}
