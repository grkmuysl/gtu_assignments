package HWSystem.Devices.WirelessIO;

import HWSystem.Devices.Device;
import HWSystem.Protocols.Protocol;

public abstract class WirelessIO extends Device{
    // constructor
    public WirelessIO(Protocol protocol, int DevID){
        super(protocol, DevID);
    }

    public abstract void sendData(String data);
    public abstract String recvData();
    @Override
    public String getDevType(){
        return "WirelessIO";
    }
}
