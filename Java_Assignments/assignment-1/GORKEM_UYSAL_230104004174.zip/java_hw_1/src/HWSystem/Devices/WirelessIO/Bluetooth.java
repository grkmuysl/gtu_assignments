package HWSystem.Devices.WirelessIO;

import HWSystem.Protocols.Protocol;

public class Bluetooth extends WirelessIO{
    // constructor
    public Bluetooth(Protocol protocol, int DevID){
        super(protocol, DevID);
    }

    protected DeviceState state = DeviceState.OFF;


    @Override
    public void sendData(String data){
        super.protocol.write(data);
        System.out.printf("Sending data. Device: %s\n" , getName());
    }

    @Override
    public String recvData(){
        String recvData = super.protocol.read();
        return recvData;
    }

    @Override
    public void turnOn(){
        System.out.printf("%s: Turning ON. \n" ,getName() );
        state = DeviceState.ON;
    }
    @Override
    public void turnOff(){
        System.out.printf("%s: Turning OFF. \n" ,getName() );
        state = DeviceState.OFF;
    }
    @Override
    public String getName(){
        return "Bluetooth";
    }

    @Override
    public DeviceState getState(){
        return state;
    }
}
