package HWSystem.Devices.Ports;

import HWSystem.Devices.Device;
import HWSystem.Protocols.Protocol;

public class Port {
    public Port(Protocol protocol, Device device, boolean isEmpty, int portId){
        this.protocol = protocol;
        this.device = device;
        this.isEmpty = isEmpty;
        this.portId = portId;
    }

    public void setDevice(Device device){
        this.device = device;
    }
    
    public void setEmptyStatus(boolean isEmpty){
        this.isEmpty = isEmpty;
    }

    public boolean getEmptyStatus(){
        return isEmpty;
    }
    public void deleteDevice(){
        this.device = null;
        this.isEmpty = true;
    }
    public Protocol protocol;
    public Device device;
    private boolean isEmpty;
    int portId;
}
