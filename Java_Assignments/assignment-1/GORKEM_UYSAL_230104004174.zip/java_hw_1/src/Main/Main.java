package Main;
import HWSystem.EmbeddedSystem.SystemManager;


public class Main {
   
    public static void main(String[] args) {

        String filePath = args[0];
        SystemManager systemManager = new SystemManager();
        systemManager.RunSystem(filePath);
    }
}
